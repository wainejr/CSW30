*.vhd: source files
*_tb.vhd: testbench files
Codficação de instruções e questões de implementação em "cod_instr.txt".
ISA utilizada em "ISA_c166.pdf" e as instruções dessa utilizadas em "ISA_instr.pdf".
Arquivos fonte para compilação e geração de ondas em "src/"
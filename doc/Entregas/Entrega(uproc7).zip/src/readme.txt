*.vhd: source files
*_tb.vhd: testbench files
top_file: processador_tb.vhd